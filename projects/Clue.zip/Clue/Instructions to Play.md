Instructions to Play

1) Unzip Clue.zip
2) Navigate to src/clueGame
3) Open "Clue.java"

I found that it works best when opened using the Eclipse IDE
