package experiment;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class IntBoard {
	public static final int BOARD_SIZE_X = 23;
	public static final int BOARD_SIZE_Y = 21;
	
	private static Map<BoardCell, Set<BoardCell>> adjacencies = new HashMap<BoardCell, Set<BoardCell>>();
	
	private static BoardCell[][] board = new BoardCell[BOARD_SIZE_X][BOARD_SIZE_Y];
	private Set<BoardCell> targets;
	
	public IntBoard() {
		for(int x = 0; x < BOARD_SIZE_X; x++) {
			for(int y = 0; y < BOARD_SIZE_Y; y++) {
				board[x][y] = new BoardCell(x, y);
			}
		}
		calcAdjacencies();
	}
	
	public static IntBoard getInstance() {
		return null;
	}
	public Map<Character, String> getLegend() {
		return null;
	}
	public static BoardCell[][] getBoard() {
//		return IntBoard.board;
		return null;
	}
	public void setConfigFiles(String boardcsv, String legend) {
		
	}
	public void initialize() {
		
	}
	public int getNumRows() {
		return 0;
	}
	public int getNumCols() {
		return 0;
	}
	private void calcAdjacencies() {
		for(int x = 0; x < BOARD_SIZE_X; x++) {
			for(int y = 0; y < BOARD_SIZE_Y; y++) {
				HashSet<BoardCell> adjacent = new HashSet<BoardCell>();
				if(x > 0) {
					adjacent.add(board[x - 1][y]);
				}
				if(x < BOARD_SIZE_X - 1) {
					adjacent.add(board[x + 1][y]);
				}
				if(y > 0) {
					adjacent.add(board[x][y - 1]);
				}
				if(y < BOARD_SIZE_Y - 1) {
					adjacent.add(board[x][y + 1]);
				}
				adjacencies.put(board[x][y], adjacent);
			}
		}
	}
	public Set<BoardCell> getAdjList(BoardCell cell) {
		return IntBoard.adjacencies.get(cell);
	}
	public Set<BoardCell> getAdjList(int x, int y) {
		return IntBoard.adjacencies.get(this.getCell(x, y));
	}
	public void calcTargets(BoardCell cell, int pathLength) {
		Set<BoardCell> targets = new HashSet<BoardCell>();
		Set<BoardCell> visited = new HashSet<BoardCell>();
		visited.add(cell);
		this.calcTargetRecursive(cell, pathLength, visited, targets);
		this.targets = targets;
	}
	public void calcTargets(int x, int y, int dist) {
		this.calcTargets(this.getCell(x, y), dist);
	}
	private void calcTargetRecursive(BoardCell cell, int stepsRemaining, Set<BoardCell> visited, Set<BoardCell> targets) {
		for(BoardCell c : IntBoard.adjacencies.get(cell)) {
			if(!visited.contains(c)) {
				if(stepsRemaining == 1) {
					targets.add(c);
				} else {
					visited.add(c);
					this.calcTargetRecursive(c, stepsRemaining - 1, visited, targets);
				}
			}
		}
	}
	public Set<BoardCell> getTargets() {
		return targets;
	}
	public BoardCell getCell(int x, int y) {
		return board[x][y];
	}
}
