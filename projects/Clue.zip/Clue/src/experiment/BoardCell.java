package experiment;

public class BoardCell {
	private int x, y;
	
	public BoardCell(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public int getX() {
		return this.x;
	}
	public int getY() {
		return this.y;
	}
}