//David Fresco and Grant Marsh

package clueGame;

public class BadConfigFormatException extends Exception {
	
	public BadConfigFormatException () {
		
	}
}
