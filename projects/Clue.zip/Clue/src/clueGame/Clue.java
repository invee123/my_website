//David Fresco and Grant Marsh

package clueGame;

public class Clue {
	
	private static Clue game;
	
	private int activeTurn = 0; //index of whichever players turn it is
	private int lastDieRoll = 1;
	private Suggestion lastGuess;
	private Card lastCard;
	public static DetectiveNotes notes;
	public static AccusationWindow accusationWindow;
	public boolean paused = false;
	
	private Clue() {
		Board.getInstance().setConfigFiles("gameboard.csv", "Rooms.txt");
		Board.getInstance().initialize();
		Player.setPlayerFile("Players.txt");
		Player.loadPlayerConfig();
		Card.createDecks();
		Solution.initializeSolution();
		Card.loadPlayerDecks();
		
		ClueWindow.start();
	}
	
	public boolean isHumansTurn() {
		return game.getActivePlayer() instanceof Human;
	}
	public Suggestion getLastSuggestion() {
		return this.lastGuess;
	}
	public Card getLastCard() {
		return this.lastCard;
	}
	public void rollDie() {
		lastDieRoll = (int)(Math.random() * 6) + 1;
		ClueWindow.getInstance().lastRoll.setText("Last die roll: " + lastDieRoll);
	}
	public int getLastDieRoll() {
		return this.lastDieRoll;
	}
	public static Clue game() {
		return Clue.game;
	}
	public Player getActivePlayer() {
		return Player.getPlayers().get(this.activeTurn);
	}
	public void updateLastSuggestion(Suggestion guess, Card returned) {
		ClueWindow.getInstance().lastGuessLabel.setText("Last guess: " + guess.getPerson().getName() + " in room " + guess.getRoom().getName() + " with the " + guess.getWeapon().getName());
		if(returned != null ) {
			ClueWindow.getInstance().guessResult.setText("Guess result: " + returned.getName());
		} else {
			ClueWindow.getInstance().guessResult.setText("Guess result: no new clue");
		}
	}
	public void nextPlayer() {
		this.activeTurn = (this.activeTurn + 1) % Player.getPlayers().size();
		this.rollDie();
		ClueWindow.getInstance().activePlayer.setText("It is " + this.getActivePlayer().getName() + "'s turn.");
		this.getActivePlayer().takeTurn();
	}
	
	public static void start() {
		game = new Clue();
		game.rollDie();
		Clue.accusationWindow = new AccusationWindow();
		Board.getInstance().calcTargets(game.getActivePlayer().getRow(), game.getActivePlayer().getColumn(), game.lastDieRoll);
		while(true) {
			if(!game.paused) {
				ClueWindow.getInstance().repaint();
			}
			Clue.notes.repaint();
		}
	}
	
	public static void main(String[] args) {
		Clue.start();
	}
}
