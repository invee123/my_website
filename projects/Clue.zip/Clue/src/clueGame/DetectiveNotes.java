//David Fresco and Grant Marsh

package clueGame;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class DetectiveNotes extends JFrame {
	
	private class Panel extends JPanel {
		
		private Panel() {
			this.setBounds(0, 0, 600, 600);
		}
		
		public void paint(Graphics g) {
			g.setColor(Color.BLACK);
			g.drawLine(0, 200, 400, 200);
			g.drawLine(0, 400, 400, 400);
			g.drawLine(400, 0, 400, 600);
		}
	}
	
	public DetectiveNotes() {
		this.setSize(600, 600);
		this.setVisible(false);
		this.setTitle("Notes ig");
		this.setResizable(false);
		this.setLayout(null);
		
		this.getContentPane().add(new Panel());
		
		this.addLabels();
		this.addCheckboxes();
		this.addDropdowns();
	}
	
	public void toggleVisible() {
		if(this.isVisible()) {
			this.setVisible(false);
		} else {
			this.setVisible(true);
		}
	}
	
	private void addLabels() {
		JLabel people = new JLabel("People");
		JLabel rooms = new JLabel("Rooms");
		JLabel weapons = new JLabel("Weapons");
		JLabel guess = new JLabel("Your Guess");
		people.setBounds(165, 20, 100, 30);
		rooms.setBounds(170, 205, 100, 30);
		weapons.setBounds(160, 405, 100, 30);
		guess.setBounds(470, 20, 100, 30);
		this.add(people);
		this.add(rooms);
		this.add(weapons);
		this.add(guess);
	}
	private void addCheckboxes() {
		//add people boxes
		for(int i = 0; i < Player.getPlayers().size(); i++) {
			JCheckBox box = new JCheckBox(Player.getPlayers().get(i).getName());
			box.setBounds(50 + (int)(i / 3) * 200, 50 + (i * 50) - (int)(i / 3) * 150, 100, 20);
			this.add(box);
		}
		
		//room boxes
		for(int i = 0; i < Card.getRoomDeck().size(); i++) {
			JCheckBox box = new JCheckBox(Card.getRoomDeck().get(i).getName());
			box.setBounds(50 + (int)(i / 5) * 200, 230 + (i * 35) - (int)(i / 5) * 175, 150, 20);
			this.add(box);
		}
		
		//weapon boxes
		for(int i = 0; i < Card.getWeaponDeck().size(); i++) {
			JCheckBox box = new JCheckBox(Card.getWeaponDeck().get(i).getName());
			box.setBounds(50 + (int)(i / 3) * 200, 430 + (i * 50) - (int)(i / 3) * 150, 100, 20);
			this.add(box);
		}
	}
	private void addDropdowns() {
		//string lists of all the types of things
		String[] people = new String[Card.getPersonDeck().size()];
		String[] rooms = new String[Card.getRoomDeck().size()];
		String[] weapons = new String[Card.getWeaponDeck().size()];
		for(int i = 0; i < rooms.length; i++) {
			rooms[i] = Card.getRoomDeck().get(i).getName();
		}
		for(int i = 0; i < people.length; i++) {
			people[i] = Card.getPersonDeck().get(i).getName();
			weapons[i] = Card.getWeaponDeck().get(i).getName();
		}
		//create dropdowns
		JComboBox<String> selectPeople = new JComboBox<String>(people);
		JComboBox<String> selectRoom = new JComboBox<String>(rooms);
		JComboBox<String> selectWeapon = new JComboBox<String>(weapons);
		
		//set bounds
		selectPeople.setBounds(420, 60, 150, 150);
		selectRoom.setBounds(420, 230, 150, 150);
		selectWeapon.setBounds(420, 400, 150, 150);
		
		//thanks stackoverflow
		((JLabel)selectPeople.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
		((JLabel)selectRoom.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
		((JLabel)selectWeapon.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
		
		//add to jframe
		this.add(selectPeople);
		this.add(selectRoom);
		this.add(selectWeapon);
	}
}
