//David Fresco and Grant Marsh

package clueGame;

import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class ClueWindow extends JFrame {
	
	private JFrame window = this;
	
	public JButton guessButton = new JButton("Guess");
	public JButton nextPlayer = new JButton("Next Player");
	public JButton accuse = new JButton("Make Accusation");
	
	public JComboBox<String> selectPeople;
//	public JComboBox<String> selectRoom;
	public JComboBox<String> selectWeapon;
	
	public JLabel activePlayer = new JLabel("It is Scarlet's turn.");
	public JLabel lastRoll = new JLabel("Last die roll was 0");
	public JLabel guessResult = new JLabel("Guess result: no new clue");
	public JLabel lastGuessLabel = new JLabel("Last guess: none");
	
	public JTextField[] cards = new JTextField[3];
	
	private class exit implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			System.exit(0);
		}
	}
	
	private class openNotes implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			Clue.notes.toggleVisible();
		}
	}
	
	private class nextPlayer implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(!Clue.game().paused) {
				if(Clue.game().getActivePlayer().turnOver()) {
					Clue.game().nextPlayer();
				}
			}
		}
	}
	
	private class makeGuess implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(!Clue.game().paused) {
				//if human player is active
				if(Clue.game().getActivePlayer() instanceof Player) {
					//if human can make a guess right now
					if(Clue.game().getActivePlayer().canGuess && !Clue.game().getActivePlayer().hasGuessed) {
						Player p = Clue.game().getActivePlayer();
						String roomName = Board.getInstance().getLegend().get(Board.getInstance().getCellAt(p.getRow(), p.getColumn()).getInitial());
						Card personCard = Card.getCard((String)ClueWindow.getInstance().selectPeople.getSelectedItem(), Card.getPersonDeck());
						Card weaponCard = Card.getCard((String)ClueWindow.getInstance().selectWeapon.getSelectedItem(), Card.getWeaponDeck());
						Card roomCard = Card.getCard(roomName, Card.getRoomDeck());
						Suggestion guess = new Suggestion(personCard, roomCard, weaponCard);
						
						Board.getInstance().handleSuggestion(guess, p.getName());
						
						p.hasGuessed = true;
					}
					if(!Clue.game().getActivePlayer().hasMoved) {
						Clue.game().getActivePlayer().makeMove(); //let the human move after
					}
				}
			}
		}
	}
	
	private class makeAccusation implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(Clue.game().isHumansTurn() && !Clue.game().getActivePlayer().hasGuessed && !Clue.game().getActivePlayer().hasMoved && !Clue.game().getActivePlayer().hasAccused) {
				Clue.accusationWindow.setVisible(true);
				Clue.game().paused = true;
			} else {
				JOptionPane.showMessageDialog(window, "Wait until your next turn to make an accusation", "Error", JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}
	
	private class click implements MouseListener {
		@Override
		public void mouseClicked(MouseEvent arg0) {	}

		@Override
		public void mouseEntered(MouseEvent arg0) {}

		@Override
		public void mouseExited(MouseEvent arg0) {}

		@Override
		public void mousePressed(MouseEvent arg0) {
			if(!Clue.game().paused) {
				//if its your turn
				if(Clue.game().isHumansTurn()) {
					//if you clicked on the board
					if(arg0.getX() <= boardWidth && arg0.getY() - 45 <= boardHeight) {
						//if the spot you clicked was a valid target
						if(Board.getInstance().getTargets().contains(Board.getInstance().getCellAt(
								(int)((arg0.getY() - 45) / Board.CELL_SIZE),
								(int)(arg0.getX() / Board.CELL_SIZE)))) {
							Clue.game().getActivePlayer().move((int)((arg0.getY() - 45) / Board.CELL_SIZE), (int)(arg0.getX() / Board.CELL_SIZE));
							Board.getInstance().getTargets().clear();
						} else {
							//otherwise throw error
							if(!Clue.game().getActivePlayer().hasMoved) {
								JOptionPane.showMessageDialog(window, "Invalid target selection", "Error", JOptionPane.ERROR_MESSAGE);
							}
						}
					}
				}
			}
		}

		@Override
		public void mouseReleased(MouseEvent arg0) {}
	}
	
	private static ClueWindow clue;
	private int width, boardWidth;
	private int height, boardHeight;
	
	private ClueWindow() {
		boardWidth = Board.getInstance().getNumCols() * Board.CELL_SIZE;
		boardHeight = Board.getInstance().getNumRows() * Board.CELL_SIZE;
		width = Board.getInstance().getNumCols() * Board.CELL_SIZE + 150;
		height = Board.getInstance().getNumRows() * Board.CELL_SIZE + 190;
		
		this.setTitle("Clue lmao");
		this.setSize(width, height);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		this.setResizable(false);
		this.addMouseListener(new click());
		
		this.addButtons();
		this.addDropdowns();
		this.addTextLabels();
		this.addDeckList();
		this.addMenu();
		
		JOptionPane.showMessageDialog(this, "You are Miss Scarlet, press okay to play", "Welcome to Clue", JOptionPane.INFORMATION_MESSAGE);
	}
	
	//file menubar options
	private void addMenu() {
		MenuBar menu = new MenuBar();
		this.setMenuBar(menu);
		
		Menu file = new Menu("File");
		menu.add(file);
		
		MenuItem notes = new MenuItem("Open notes");
		notes.addActionListener(new openNotes());
		MenuItem exit = new MenuItem("Exit");
		exit.addActionListener(new exit());
		
		file.add(notes);
		file.add(exit);
	}
	
	private void addButtons() {
		guessButton.setBounds(150, boardHeight + 40, 80, 80);
		guessButton.addActionListener(new makeGuess());
		this.add(guessButton);
		
		nextPlayer.setBounds(450, boardHeight + 10, 240, 50);
		nextPlayer.addActionListener(new nextPlayer());
		this.add(nextPlayer);
		
		accuse.setBounds(450, boardHeight + 70, 240, 50);
		accuse.addActionListener(new makeAccusation());
		this.add(accuse);
	}
	private void addDropdowns() {
		String[] people = new String[Card.getPersonDeck().size()];
		String[] rooms = new String[Card.getRoomDeck().size()];
		String[] weapons = new String[Card.getWeaponDeck().size()];
		for(int i = 0; i < rooms.length; i++) {
			rooms[i] = Card.getRoomDeck().get(i).getName();
		}
		for(int i = 0; i < people.length; i++) {
			people[i] = Card.getPersonDeck().get(i).getName();
			weapons[i] = Card.getWeaponDeck().get(i).getName();
		}
		selectPeople = new JComboBox<String>(people);
//		selectRoom = new JComboBox<String>(rooms);
		selectWeapon = new JComboBox<String>(weapons);
		selectPeople.setBounds(20, boardHeight + 40, 110, 20);
//		selectRoom.setBounds(20, boardHeight + 70, 110, 20);
		selectWeapon.setBounds(20, boardHeight + 100, 110, 20);
		this.add(selectPeople);
//		this.add(selectRoom);
		this.add(selectWeapon);
	}
	private void addTextLabels() {
		activePlayer.setBounds(250, boardHeight + 40, 300, 20);
		lastRoll.setBounds(250, boardHeight + 70, 280, 20);
		guessResult.setBounds(250, boardHeight + 100, 300, 20);
		lastGuessLabel.setBounds(20, boardHeight + 10, 500, 20);
		this.add(activePlayer);
		this.add(lastRoll);
		this.add(guessResult);
		this.add(lastGuessLabel);
	}
	private void addDeckList() {
		JLabel yourCards = new JLabel("Your cards");
		yourCards.setBounds(boardWidth + 45, 40, 100, 20);
		this.add(yourCards);
		
		for(int i = 0; i < Player.getPlayers().get(0).getDeck().size(); i++) {
			cards[i] = new JTextField(Player.getPlayers().get(0).getDeck().get(i).getName());
			cards[i].setBounds(boardWidth + 25, 80 + (i * 170), 100, 150);
			cards[i].setHorizontalAlignment(JTextField.CENTER);
			cards[i].setEditable(false);
			this.add(cards[i]);
		}
	}
	
	public int getWidth() {
		return width;
	}
	public int getHeight() {
		return height;
	}
	public int getBoardWidth() {
		return boardWidth;
	}
	public int getBoardHeight() {
		return boardHeight;
	}
	public static ClueWindow getInstance() {
		return clue;
	}
	
	public static void start() {
		Clue.notes = new DetectiveNotes();
		clue = new ClueWindow();
		clue.getContentPane().add(Board.getInstance());
	}
}
