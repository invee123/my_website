package clueGame;

import java.util.Set;

import javax.swing.JOptionPane;

public class Human extends Player {

	public Human(String playerName, int row, int column, String color) {
		super(playerName, row, column, color);
	}
	
	public Set<Card> getSeenCards() {
		return this.seenCards;
	}
	public boolean hasSeenCard(Card card) {
		return seenCards.contains(card);
	}
	
	@Override
	public void takeTurn() {
		super.takeTurn();
		this.hasMoved = false;
		super.makeGuess();
		if(!this.canGuess) {
			this.makeMove();
		} else {
			JOptionPane.showMessageDialog(ClueWindow.getInstance(), "You entered a room, make a guess to proceed", "Make a guess", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	@Override
	public void makeMove() {
		super.makeMove();
		Board.getInstance().calcTargets(Clue.game().getActivePlayer().getRow(), Clue.game().getActivePlayer().getColumn(), Clue.game().getLastDieRoll());
	}
	
	public void witnessSuggestion(Suggestion s) {
		seenCards.add(s.getPerson());
		seenCards.add(s.getRoom());
		seenCards.add(s.getWeapon());
	}
}
