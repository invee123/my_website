//David Fresco and Grant Marsh

package clueGame;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map.Entry;
import java.util.Scanner;

public class Card {
	public enum CardType {
		PERSON, WEAPON, ROOM;
	}
	
	private static ArrayList<Card> personDeck = new ArrayList<Card>();
	private static ArrayList<Card> weaponDeck = new ArrayList<Card>();
	private static ArrayList<Card> roomDeck = new ArrayList<Card>();
	
	private CardType type;
	private String cardName;
	
	private Card(CardType type, String cardName) {
		this.type = type;
		this.cardName = cardName;
	}
	public static void loadPlayerDecks() {
		ArrayList<Card> allCards = new ArrayList<Card>();
		for(Card c : personDeck) {
			allCards.add(c);
		}
		for(Card c : roomDeck) {
			allCards.add(c);
		}
		for(Card c : weaponDeck) {
			allCards.add(c);
		}
		Collections.shuffle(allCards);
		int offset = 0;
		for(int i = 0; i < allCards.size()-3; i++) {
			if(Solution.getSolution().getPerson().equals(allCards.get(i))) {
				if(i == allCards.size() - 3) {
					break;
				} else {
					offset++;
				}
			}
			Player.getPlayers().get(i % Player.getPlayers().size()).dealCard(allCards.get(i + offset));
			
		}
	}
	public static void createDecks() {
		personDeck.clear();
		weaponDeck.clear();
		roomDeck.clear();
		for(Player p : Player.getPlayers())
			personDeck.add(new Card(CardType.PERSON, p.getName()));
		for(char key : Board.getInstance().getLegend().keySet()) {
			if(key != 'W' && key != 'X') {
				roomDeck.add(new Card(CardType.ROOM, Board.getInstance().getLegend().get(key)));
			}
		}
		File weaponFile = new File("Weapons.txt");
		Scanner in;
		try {
			in = new Scanner(weaponFile);
		} catch (FileNotFoundException e) {
			System.out.println("Weapon file not found");
			return;
		}
		while(in.hasNextLine()) {
			weaponDeck.add(new Card(CardType.WEAPON, in.nextLine()));
		}
		in.close();
	}
	
	public String getName() {
		return this.cardName;
	}
	
	public CardType getType() {
		return this.type;
	}

	public static ArrayList<Card> getPersonDeck() {
		return personDeck;
	}

	public static ArrayList<Card> getWeaponDeck() {
		return weaponDeck;
	}

	public static ArrayList<Card> getRoomDeck() {
		return roomDeck;
	}
	public static Card getCard(String name, ArrayList<Card> deck) {
		for(Card c : deck) {
			if(c.getName().equals(name)) {
				return c;
			}
		}
		return null;
	}
}