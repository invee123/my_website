package clueGame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class AccusationWindow extends JFrame {
	
	JComboBox<String> selectPeople;
	JComboBox<String> selectRoom;
	JComboBox<String> selectWeapon;
	
	private class makeAccusation implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			Card personCard = Card.getCard((String)selectPeople.getSelectedItem(), Card.getPersonDeck());
			Card roomCard = Card.getCard((String)selectRoom.getSelectedItem(), Card.getRoomDeck());
			Card weaponCard = Card.getCard((String)selectWeapon.getSelectedItem(), Card.getWeaponDeck());
			
			Board.getInstance().accuse(Player.getPlayers().get(0), new Suggestion(personCard, roomCard, weaponCard));
			
			new exit().actionPerformed(e);
		}
	}
	
	private class exit implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			Clue.accusationWindow.setVisible(false);
			Clue.game().paused = false;
		}
	}
	
	public AccusationWindow() {
		this.setTitle("Make Accusation");
		this.setSize(290, 190);
		this.setResizable(false);
		this.setLayout(null);
		
		this.addDropdowns();
		
		JButton accuse = new JButton("Accuse");
		accuse.setBounds(170, 10, 100, 65);
		accuse.addActionListener(new makeAccusation());
		this.add(accuse);
		
		JButton exit = new JButton("Exit");
		exit.setBounds(170, 85, 100, 65);
		exit.addActionListener(new exit());
		this.add(exit);
		
		this.setVisible(false);
	}
	
	private void addDropdowns() {
		//string lists of all the types of things
		String[] people = new String[Card.getPersonDeck().size()];
		String[] rooms = new String[Card.getRoomDeck().size()];
		String[] weapons = new String[Card.getWeaponDeck().size()];
		for(int i = 0; i < rooms.length; i++) {
			rooms[i] = Card.getRoomDeck().get(i).getName();
		}
		for(int i = 0; i < people.length; i++) {
			people[i] = Card.getPersonDeck().get(i).getName();
			weapons[i] = Card.getWeaponDeck().get(i).getName();
		}
		//create dropdowns
		selectPeople = new JComboBox<String>(people);
		selectRoom = new JComboBox<String>(rooms);
		selectWeapon = new JComboBox<String>(weapons);
		
		//set bounds
		selectPeople.setBounds(10, 10, 150, 40);
		selectRoom.setBounds(10, 60, 150, 40);
		selectWeapon.setBounds(10, 110, 150, 40);
		
		//add to jframe
		this.add(selectPeople);
		this.add(selectRoom);
		this.add(selectWeapon);
	}
}
