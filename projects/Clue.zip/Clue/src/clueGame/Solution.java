package clueGame;

import java.util.Random;

public class Solution {
	
	private Card person;
	private Card room;
	private Card weapon;
	private static Solution soln;

	public Solution(Card person, Card room, Card weapon) {
		this.person = person;
		this.room = room;
		this.weapon = weapon;
	}
	
	public static void initializeSolution() {
		soln = Solution.createSolution();
	}
	private static Solution createSolution() {
		Random rand = new Random(System.currentTimeMillis());
		Card person = Card.getPersonDeck().get(rand.nextInt(Card.getPersonDeck().size()));
		Card room = Card.getRoomDeck().get(rand.nextInt(Card.getRoomDeck().size()));
		Card weapon = Card.getWeaponDeck().get(rand.nextInt(Card.getWeaponDeck().size()));
		return new Solution(person, room, weapon);
	}
	public boolean checkSolution() {
		return this.equals(soln) ? true : false;
	}
	public static Solution getSolution() {
		return soln;
	}
	public boolean equals(Solution soln) {
		if(this.person.equals(soln.person)
				&& this.room.equals(soln.room)
				&& this.weapon.equals(soln.weapon)) {
			return true;
		}
		return false;
	}
	public Card getPerson() {
		return person;
	}
	public Card getRoom() {
		return room;
	}
	public Card getWeapon() {
		return weapon;
	}
	public String toString() {
		return person.getName() + " in " + room.getName() + " with " + weapon.getName();
	}
}
