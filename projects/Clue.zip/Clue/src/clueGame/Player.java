//David Fresco and Grant Marsh

package clueGame;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public abstract class Player {
	private String playerName;
	private int row;
	private int column;
	private Color color;
	private static String playerFileName;
	private ArrayList<Card> deck = new ArrayList<Card>();
	protected Set<Card> seenCards = new HashSet<Card>();
	protected boolean hasMoved = false;
	protected boolean canGuess = false;
	protected boolean hasGuessed = false;
	protected boolean hasAccused = false;
	private Random rand = new Random(System.currentTimeMillis());
	
	private static ArrayList<Player> players = new ArrayList<Player>();
	
	public Player(String playerName, int row, int column, String color) {
		this.playerName = playerName;
		this.row = row;
		this.column = column;
		try {
			// We can use reflection to convert the string to a color
			Field field = Class.forName("java.awt.Color").getField(color.trim());
			this.color = (Color)field.get(null);
		} catch (Exception e) {
			this.color = null; // Not defined
		}
	}
	
	public static void loadPlayerConfig() {
		players.clear();
		File playerFile;
		Scanner in;
		try {
			playerFile = new File(playerFileName);
			in = new Scanner(playerFile);
		} catch (FileNotFoundException e) {
			System.out.println("Invalid player file: " + playerFileName);
			return;
		}
		while(in.hasNext()) {
			String[] line = in.nextLine().split(", ");
			if(line[2].equals("Human")) {
				players.add(new Human(line[0], Integer.parseInt(line[3]), Integer.parseInt(line[4]), line[1]));
			} else if(line[2].equals("Computer")) {
				players.add(new Computer(line[0], Integer.parseInt(line[3]), Integer.parseInt(line[4]), line[1]));
			} else {
				System.out.println("Improperly formatted player: " + line[0]);
			}
		}
		in.close();
	}
	
	public void makeMove() {
		this.hasMoved = false;
	}
	
	public void move(int row, int col) {
		this.row = row;
		this.column = col;
		this.hasMoved = true;
	}
	
	private Card getUnseenCard(ArrayList<Card> deck) {
		//try to return an unseen
		for(Card c : deck) {
			if(!this.seenCards.contains(c)) {
				return c;
			}
		}
		//if we've seen all the cards, return a random one
		return deck.get(Math.abs(rand.nextInt()) % deck.size());
	}
	
	public void seeDisprovedCard(Suggestion s) {
		Card seen = Board.getInstance().handleSuggestion(s, this.playerName);
		if(seen != null) {
			this.seenCards.add(seen);
		}
	}
	
	public boolean hasCard(Card card) {
		for(Card c : this.deck) {
			if(c.equals(card)) {
				return true;
			}
		}
		return false;
	}
	
	public void dealCard(Card c) {
		this.deck.add(c);
	}

	public static ArrayList<Player> getPlayers() {
		return players;
	}
	
	public boolean turnOver() {
		if(!this.hasMoved) return false;
		if(!this.canGuess) return true;
		if(this.canGuess && !this.hasGuessed) return false;
		return true;
	}
	
	public void makeGuess() {
		this.canGuess = false;
		this.hasGuessed = false;
		//if player isnt in a room you cant make a guess
		if(Board.getInstance().getCellAt(this.getRow(), this.getColumn()).isRoom()) {
			this.canGuess = true;
		}
	}
	
	public void takeTurn() {
		this.hasAccused = false;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

	public String getName() {
		return playerName;
	}

	public Color getColor() {
		return color;
	}
	
	public ArrayList<Card> getDeck() {
		return deck;
	}
	
	public void setDeck(ArrayList<Card> deck) {
		this.deck = deck;
	}
	
	public Set<Card> getSeenCards() {
		return this.seenCards;
	}
	
	public static void setPlayerFile(String fileName) {
		playerFileName = fileName;
	}
	
	public void seeReturnedCard(Card c) {
		this.seenCards.add(c);
	}

	public Card disproveSuggestion(Suggestion suggestion) {
		
		ArrayList<Card> matchingCards = new ArrayList<Card>();
		for(Card c : this.getDeck()) {
			if(suggestion.getPerson().getName().equals(c.getName())) {
				matchingCards.add(c);
			}
			if(suggestion.getRoom().equals(c)) {
				matchingCards.add(c);
			}
			if(suggestion.getWeapon().getName().equals(c.getName())) {
				matchingCards.add(c);
			}
		}
		return matchingCards.isEmpty() ? null : randomCard(matchingCards);
	}
	
	public Card randomCard(ArrayList<Card> matchingCards) {
		return matchingCards.get(new Random(System.currentTimeMillis()).nextInt(matchingCards.size()));
	}
	public static Suggestion createRandomSuggestion(Player p) {
		Card room = null;
		String roomName = Board.getInstance().getLegend().get(Board.getInstance().getCellAt(p.getRow(), p.getColumn()).getInitial());
		for(Card c : Card.getRoomDeck())
			if(c.getName().equals(roomName)) room = c;
		Card person = p.getUnseenCard(Card.getPersonDeck());
		Card weapon = p.getUnseenCard(Card.getWeaponDeck());
		
		return new Suggestion(person, room, weapon);
	}
}
