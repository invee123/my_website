//David Fresco and Grant Marsh

package clueGame;

import java.awt.Color;
import java.awt.Graphics;

public class BoardCell {
	public enum DoorDirection {
		UP('U'),
		DOWN('D'),
		LEFT('L'),
		RIGHT('R'),
		NONE(' ');
		
		char initial;
		DoorDirection(char initial) {
			this.initial = initial;
		}
	}
	
	private int row;
	private int column; 
	private char initial = ' ';
	private boolean isDoor = false;
	private DoorDirection direction;
	
	public BoardCell(int col, int row, String attributes) {
		this.row = row;
		this.column = col;
		this.initial = attributes.charAt(0);
		if(attributes.length() > 1 && attributes.charAt(1) != 'N') {
			isDoor = true;
			for(DoorDirection direction : DoorDirection.values()) {
				if(direction.initial == attributes.charAt(1)) {
					this.direction = direction;
				}
			}
		}
	}
	
	public void draw(Graphics g) {
		if(this.isWalkway() || Board.getInstance().getTargets().contains(this)) {
			g.setColor(Color.LIGHT_GRAY);
			if(Board.getInstance().getTargets().contains(this)) {
				g.setColor(new Color(150, 150, 0));
			}
			g.fillRect(column * Board.CELL_SIZE, row * Board.CELL_SIZE, Board.CELL_SIZE, Board.CELL_SIZE);
			
			g.setColor(Color.BLACK);
			//top line
			g.drawLine(
					column * Board.CELL_SIZE,
					row * Board.CELL_SIZE,
					column * Board.CELL_SIZE + Board.CELL_SIZE,
					row * Board.CELL_SIZE);
			//left line
			g.drawLine(
					column * Board.CELL_SIZE,
					row * Board.CELL_SIZE,
					column * Board.CELL_SIZE,
					row * Board.CELL_SIZE+ Board.CELL_SIZE);
			//bottom line
			g.drawLine(
					column * Board.CELL_SIZE,
					row * Board.CELL_SIZE + Board.CELL_SIZE,
					column * Board.CELL_SIZE + Board.CELL_SIZE,
					row * Board.CELL_SIZE+ Board.CELL_SIZE);
			//right line
			g.drawLine(
					column * Board.CELL_SIZE + Board.CELL_SIZE,
					row * Board.CELL_SIZE,
					column * Board.CELL_SIZE + Board.CELL_SIZE,
					row * Board.CELL_SIZE+ Board.CELL_SIZE);
		}
		g.setColor(Color.DARK_GRAY);
		if(this.isDoor) {
			switch (this.getDoorDirection()) {
			case UP:
				g.fillRect(column * Board.CELL_SIZE, row * Board.CELL_SIZE, Board.CELL_SIZE, 5);
				break;
			case LEFT:
				g.fillRect(column * Board.CELL_SIZE, row * Board.CELL_SIZE, 5, Board.CELL_SIZE);
				break;
			case DOWN:
				g.fillRect(column * Board.CELL_SIZE, row * Board.CELL_SIZE + 25, Board.CELL_SIZE, 5);
				break;
			case RIGHT:
				g.fillRect(column * Board.CELL_SIZE + 25, row * Board.CELL_SIZE, 5, Board.CELL_SIZE);
				break;
			default:
				break;
			}
		}
	}
	
	public boolean accessibleFromWalkway(DoorDirection expectedDirection) {
		if(this.isWalkway()) {
			return true;
		}
		if(this.isDoor && this.direction == expectedDirection) {
			return true;
		}
		return false;
	}
	
	public boolean isDoorway() {
		return this.isDoor;
	}
	public boolean isWalkway() {
		return this.initial == 'W';
	}
	public boolean isRoom() {
		return this.initial != 'W' && this.initial != 'X';
	}
	public DoorDirection getDoorDirection() {
		return this.direction;
	}
	public char getInitial() {
		return this.initial;
	}
	public String toString() {
		return "(" + row + ", " + column + ")";
	}
	public int getRow() {
		return this.row;
	}
	public int getColumn() {
		return this.column;
	}
}