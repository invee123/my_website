//David Fresco and Grant Marsh

package clueGame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import clueGame.BoardCell.DoorDirection;

public class Board extends JPanel {
	public static final int MAX_BOARD_SIZE = 50;
	public static final int CELL_SIZE = 30;
	
	private static Board b = new Board();
	
	private int numRows;
	private int numColumns;
	private BoardCell[][] gameBoard; 
	private Map<Character, String> legend;
	private Map<BoardCell, Set<BoardCell>> adjMatrix = new HashMap<>(); 
	private Set<BoardCell> targets = new HashSet<BoardCell>();
	private String boardConfigFile;
	private String roomConfigFile;
	
	private Board() {
		this.legend = new LinkedHashMap<>(); 
		this.setBounds(0, 0, 1000, 1000);
	}
	
	public static Board getInstance() { 
		return b;
	}
	
	@Override
	public void paint(Graphics g) {
		//background color
		g.setColor(new Color(150, 150, 150));
		g.fillRect(0, 0, ClueWindow.getInstance().getBoardWidth(), ClueWindow.getInstance().getBoardHeight());
		
		//board cells
		for(BoardCell[] row : gameBoard) {
			for(BoardCell cell : row) {
				if(cell != null ) {
					cell.draw(g);
				}
			}
		}
		
		//room names
		g.setColor(Color.BLACK);
		((Graphics2D)g).drawString("Treasurer's Room", 40, 55);
		((Graphics2D)g).drawString("AGT", 290, 90);
		((Graphics2D)g).drawString("Pindate", 590, 55);
		((Graphics2D)g).drawString("Middle", 45, 260);
		((Graphics2D)g).drawString("Double", 55, 510);
		((Graphics2D)g).drawString("Scott's Van", 195, 560);
		((Graphics2D)g).drawString("Basement", 390, 550);
		((Graphics2D)g).drawString("Harry Potter", 570, 530);
		((Graphics2D)g).drawString("Library", 600, 275);
		((Graphics2D)g).drawString("Closet", 310, 320);
		
		//draw players
		for(Player p : Player.getPlayers()) {
			g.setColor(p.getColor());
			g.fillOval(p.getColumn() * CELL_SIZE, p.getRow() * CELL_SIZE, CELL_SIZE, CELL_SIZE);
		}
	 	
	 	//draw bounding lines on the board edges
	 	g.setColor(Color.BLACK);
	 	g.drawLine(0, this.numRows * CELL_SIZE, this.numColumns * CELL_SIZE, this.numRows * CELL_SIZE);
	 	g.drawLine(this.numColumns * CELL_SIZE, 0, this.numColumns * CELL_SIZE, this.numRows * CELL_SIZE);
	}
	
	public void initialize() {
		try {
			this.loadRoomConfig();
		} catch (BadConfigFormatException e) {
			System.out.println("File " + this.roomConfigFile + " configured improperly");
			return;
		}
		try {
			this.loadBoardConfig();
		} catch (BadConfigFormatException e) {
			System.out.println("File " + this.boardConfigFile + " configured improperly");
			return;
		}
		this.initAdjList();
	}
	public void loadRoomConfig() throws BadConfigFormatException {
		File legendFile = new File(this.roomConfigFile);
		Scanner in;
		try {
			in = new Scanner(legendFile);
		} catch (FileNotFoundException e) {
			System.out.println("Room config file not found");
			return;
		}
		while(in.hasNext()) {
			//for each line...
			String[] line = in.nextLine().split(", "); //input line as an array of character, name, and designation
			String roomName = line[1];
			if(!line[2].equals("Card") && !line[2].equals("Other")) {
				throw new BadConfigFormatException();
			}
			this.legend.put(line[0].toCharArray()[0], roomName);
		}
		in.close();
	}
	public void loadBoardConfig() throws BadConfigFormatException {
		File boardFile = new File(this.boardConfigFile);
		Scanner in;
		try {
			in = new Scanner(boardFile);
		} catch (FileNotFoundException e) { //if the scanner fails, just return the function
			return;
		}
		gameBoard = new BoardCell[MAX_BOARD_SIZE][MAX_BOARD_SIZE];
		in.useDelimiter(",");
		int y = 0;
		while(in.hasNextLine()) {
			String[] row = in.nextLine().split(","); //go line by line (y > y+1)
			if(y == 0) this.numColumns = row.length; //if its the first line, get the number of columns based on the length of the first row
			this.testValidEntry(row); //make sure the row input is formatted properly
			for(int x = 0; x < this.numColumns; x++) {
				gameBoard[x][y] = new BoardCell(x, y, row[x]); //put new boardcell in board
			}
			y++; //increment y (row) value
		}
		this.numRows = y; //once we've reached the end of the stream, count how many rows we did and make that the number of rows
		in.close();
	}
	private void testValidEntry(String[] row) throws BadConfigFormatException {
		//if the row being tested is a different length than the others, fail
		if(row.length != this.numColumns) {
			throw new BadConfigFormatException();
		}
		//if any value in the row is invalid, throw an exception too
		for(int x = 0; x < this.numColumns; x++) {
			if(row.length != this.numColumns || !this.legend.containsKey(row[x].charAt(0))) {
				throw new BadConfigFormatException();
			}
		}
	}
	private void initAdjList() {
		for(int row = 0; row < this.numRows; row++) {
			for(int col = 0; col < this.numColumns; col++) {
				this.adjMatrix.put(gameBoard[col][row], this.getAdjacents(row, col));
			}
		}
	}
	private Set<BoardCell> getAdjacents(int row, int col) {
		Set<BoardCell> adj = new HashSet<>();
		//check above cell
		BoardCell cell = gameBoard[col][row];
		if(cell.isWalkway()) {	
			//check above cell
			if(row < this.numRows - 1) {
				cell = gameBoard[col][row + 1];
				if(cell.accessibleFromWalkway(DoorDirection.UP)) {
					adj.add(cell);
				}
			}
			//check below cell
			if(row > 0) {
				cell = gameBoard[col][row - 1];
				if(cell.accessibleFromWalkway(DoorDirection.DOWN)) {
					adj.add(cell);
				}
			}
			//check left cell
			if(col > 0) {
				cell = gameBoard[col - 1][row];
				if(cell.accessibleFromWalkway(DoorDirection.RIGHT)) {
					adj.add(cell);
				}
			}
			//check right cell
			if(col < this.numColumns - 1) {
				cell = gameBoard[col + 1][row];
				if(cell.accessibleFromWalkway(DoorDirection.LEFT)) {
					adj.add(cell);
				}
			}
		} else if(cell.isDoorway()) { //moves 1 space in the direction the door is facing (into walkway)
			if(cell.getDoorDirection() == DoorDirection.UP) {
				adj.add(gameBoard[col][row - 1]);
			}
			if(cell.getDoorDirection() == DoorDirection.DOWN) {
				adj.add(gameBoard[col][row + 1]);
			}
			if(cell.getDoorDirection() == DoorDirection.LEFT) {
				adj.add(gameBoard[col - 1][row]);
			}
			if(cell.getDoorDirection() == DoorDirection.RIGHT) {
				adj.add(gameBoard[col + 1][row]);
			}
		}
		return adj;
	}
	private void calcTargets(BoardCell cell, int pathLength) {
		Set<BoardCell> calculatedTargets = new HashSet<>();
		Set<BoardCell> visited = new HashSet<>();
		visited.add(cell);
		this.calcTargetRecursive(cell, pathLength, visited, calculatedTargets);
		this.targets = calculatedTargets;
	}
	public void calcTargets(int row, int col, int dist) { //used if input format is given in row/col/dist instead of boardCell[row][col]/dist
		this.calcTargets(this.getCellAt(row, col), dist);
	}
	private void calcTargetRecursive(BoardCell cell, int stepsRemaining, Set<BoardCell> visited, Set<BoardCell> targets) {
		for(BoardCell c : adjMatrix.get(cell)) {
			if(!visited.contains(c)) { //checks to see if cell has been visited (avoid backtracking)
				if(stepsRemaining == 1) { //if it hasn't and its the last movement, add it to targets
					targets.add(c);
				} else {
					if(c.isRoom()) { //if it's a room, add it to targets
						targets.add(c);
					}
					Set<BoardCell> newVisited = new HashSet<>(); //creates new set to store previous visited cells as well as the current cell
					newVisited.addAll(visited);
					newVisited.add(c);
					this.calcTargetRecursive(c, stepsRemaining - 1, newVisited, targets);
				}
			}
		}
	}
	public void setConfigFiles(String board, String legend) {
		this.boardConfigFile = board;
		this.roomConfigFile = legend;
	}
	public Map<Character, String> getLegend() {
		return legend;
	}
	public int getNumRows() {
		return this.numRows;
	}
	public int getNumCols() {
		return this.numColumns;
	}

	public BoardCell getCellAt(int row, int col) {
		return gameBoard[col][row];
	}
	public Set<BoardCell> getTargets() {
		return this.targets;
	}
	public Set<BoardCell> getAdjList(int row, int col) {
		return this.adjMatrix.get(gameBoard[col][row]);
	}
	

	public Card handleSuggestion(Suggestion suggestion, String name) {
		if(suggestion.checkSolution()) {
			return null;
		}
		//get the player making the guess
		Player player = null;
		//and the player implicated
		Player accused = null;
		for(Player p : Player.getPlayers()) {
			if(p.getName().equals(name)) {
				player = p;
			}
			if(p.getName().equals(suggestion.getPerson().getName())) {
				accused = p;
			}
		}
		
		//move accused player to the position (and room) of the accuser
		accused.move(player.getRow(), player.getColumn());
		//set this flag to false so it doesnt skip the turn of the person moving
		accused.hasMoved = false;
		
		//return null if guesser holds all cards in guess
		if(player.getDeck().contains(suggestion.getPerson())
				&& player.getDeck().contains(suggestion.getRoom())
				&& player.getDeck().contains(suggestion.getWeapon())) {
			return null;
		}
		
		//get index of guesser
		int index = 0;
		for(int i = 0; i < Player.getPlayers().size(); i++) {
			if(Player.getPlayers().get(i).getName().equals(name)) {
				index = i;
			}
		}
		
		//keep asking the next person until one of them shows a card or all players are checked
		Player nextPlayer = Player.getPlayers().get((index + 1) % Player.getPlayers().size());
		Card card = nextPlayer.disproveSuggestion(suggestion);
		int peopleChecked = 1;
		while(card == null && peopleChecked < Player.getPlayers().size()) {
			index++;
			nextPlayer = Player.getPlayers().get((index + 1) % Player.getPlayers().size());
			card = nextPlayer.disproveSuggestion(suggestion);
			peopleChecked++;
		}
		
		Clue.game().updateLastSuggestion(suggestion, card); //update gui
		//have all players add the card to their seen cards list
		for(Player p : Player.getPlayers()) {
			p.seeReturnedCard(card);
		}
		return card;
	}
	public void accuse(Player p, Suggestion s) {
		//end players turn\
		Clue.game().getActivePlayer().hasAccused = true;
		Clue.game().getActivePlayer().hasGuessed = true;
		Clue.game().getActivePlayer().hasMoved = true;
		Board.getInstance().getTargets().clear();
		
		if(s.checkSolution()) { //if soln is right
			JOptionPane.showMessageDialog(this, p.getName() + " won! The solution was " + Solution.getSolution(), "Game Over", JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);
		} else {
			JOptionPane.showMessageDialog(this, p.getName() + " guessed the solution incorrectly. Their guess was " + s, "Game Over", JOptionPane.INFORMATION_MESSAGE);
		}
	}
}
