package clueGame;

public class Suggestion {
	
	private Card person;
	private Card room;
	private Card weapon;

	public Suggestion(Card person, Card room, Card weapon) {
		this.person = person;
		this.room = room;
		this.weapon = weapon;
	}
	
	public boolean checkSolution() {
		if(this.person.equals(Solution.getSolution().getPerson())
				&& this.room.equals(Solution.getSolution().getRoom())
				&& this.weapon.equals(Solution.getSolution().getWeapon())) {
			return true;
		}
		return false;
	}
	
	public boolean equals(Suggestion soln) {
		if(this.person.equals(soln.person)
				&& this.room.equals(soln.room)
				&& this.weapon.equals(soln.weapon)) {
			return true;
		}
		return false;
	}
	public Card getPerson() {
		return person;
	}
	public Card getRoom() {
		return room;
	}
	public Card getWeapon() {
		return weapon;
	}
	public String toString() {
		return person.getName() + " in " + room.getName() + " with " + weapon.getName();
	}
}
