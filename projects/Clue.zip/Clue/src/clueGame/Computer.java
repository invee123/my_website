package clueGame;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import clueGame.Card.CardType;

public class Computer extends Player {
	
	private Set<Character> visitedRooms = new HashSet<Character>();
	private Suggestion lastGuess = null;
	private boolean lastGuessWasNull = false;

	public Computer(String playerName, int row, int column, String color) {
		super(playerName, row, column, color);
		for(Card c : this.getDeck()) {
			this.seenCards.add(c);
		}
	}
	
	@Override
	public void takeTurn() {
		super.takeTurn();
		super.makeGuess();
		this.makeGuess();
		this.makeMove();
	}
	
	@Override
	public void makeGuess() {
		//if someone could disprove the last guess
		if(!lastGuessWasNull || this.seenCards.size() == 18) {
			//if the player is in a room and can guess
			if(this.canGuess) {
				//make a new guess
				Suggestion guess = Player.createRandomSuggestion(this);
				this.lastGuess = guess;
				
				Card returned = Board.getInstance().handleSuggestion(guess, this.getName());
				if(returned == null) lastGuessWasNull = true;
				this.hasGuessed = true;
			}
		} else { //if nobody could disprove the last guess
			Board.getInstance().accuse(this, lastGuess);
		}
	}
	
	public BoardCell selectTarget(int distance) {
		ArrayList<BoardCell> targets = new ArrayList<BoardCell>();
		for(BoardCell b : this.getTargets(distance))
				targets.add(b);
		Board.getInstance().getTargets().clear();
		return targets.get(new Random(System.currentTimeMillis()).nextInt(targets.size()));
	}
	
	@Override
	public void makeMove() {
		super.makeMove();
		BoardCell target = this.selectTarget(Clue.game().getLastDieRoll());
		this.move(target.getRow(), target.getColumn());
		if(Board.getInstance().getCellAt(this.getRow(), this.getColumn()).isRoom()) {
			visitedRooms.add(Board.getInstance().getCellAt(this.getRow(), this.getColumn()).getInitial());
		}
	}
	
	public Set<BoardCell> getTargets(int distance) {
		Set<BoardCell> doorTargets = new HashSet<BoardCell>();
		Set<BoardCell> walkwayTargets = new HashSet<BoardCell>();
		Board.getInstance().calcTargets(this.getRow(), this.getColumn(), distance);
		
		for(BoardCell b : Board.getInstance().getTargets()) {
			if(b.isDoorway()) {
				if(!visitedRooms.contains(b.getInitial())) {
					doorTargets.add(b);
				}
			} else { 
				walkwayTargets.add(b);
			}
		}
		if(!doorTargets.isEmpty()) {
			return doorTargets;
		} else {
			return walkwayTargets;
		}
	}
	public Set<Card> getSeenCards() {
		return this.seenCards;
	}
	public boolean hasSeenCard(Card card) {
		return seenCards.contains(card);
	}
	
	
	public void witnessSuggestion(Suggestion s) {
		seenCards.add(s.getPerson());
		seenCards.add(s.getRoom());
		seenCards.add(s.getWeapon());
	}
}
