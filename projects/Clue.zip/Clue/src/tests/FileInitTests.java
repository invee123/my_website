//David Fresco and Grant Marsh

package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import clueGame.Board;
import clueGame.BoardCell.DoorDirection;

public class FileInitTests {
	
	// Constants that I will use to test whether the file was loaded correctly
	public static final int LEGEND_SIZE = 11;
	public static final int NUM_ROWS = 21;
	public static final int NUM_COLUMNS = 23;

	private static Board board = Board.getInstance();
	
	@Before
	public void init() {
		board.setConfigFiles("gameboard.csv", "Rooms.txt");
		board.initialize();
	}
	
	@Test
	public void testLegend() {
		// Get the map of initial => room 
		Map<Character, String> legend = board.getLegend();
		// Ensure we read the correct number of rooms
		assertEquals(LEGEND_SIZE, legend.size());
		// To ensure data is correctly loaded, test retrieving a few rooms 
		// from the hash, including the first and last in the file and a few others
		assertEquals("Treasurer's Room", legend.get('T'));
		System.out.println(legend.get('S'));
		assertEquals("Scott's Van", legend.get('S'));
		assertEquals("Pindate", legend.get('P'));
	}
	
	@Test
	public void testBoardSize() {
		// Ensure we have the proper number of rows and columns
		assertEquals(NUM_ROWS, board.getNumRows());
		assertEquals(NUM_COLUMNS, board.getNumCols());	
	}
	
	@Test
	public void testDoorDirections() {
		//test all four directions of doorway
		assertTrue(board.getCellAt(2, 11).isDoorway());
		assertEquals(board.getCellAt(2, 11).getDoorDirection(), DoorDirection.RIGHT);
		assertTrue(board.getCellAt(1, 15).isDoorway());
		assertEquals(board.getCellAt(1, 15).getDoorDirection(), DoorDirection.LEFT);
		assertTrue(board.getCellAt(10, 2).isDoorway());
		assertEquals(board.getCellAt(10, 2).getDoorDirection(), DoorDirection.DOWN);
		assertTrue(board.getCellAt(14, 19).isDoorway());
		assertEquals(board.getCellAt(14, 19).getDoorDirection(), DoorDirection.UP);
		
		//make sure isDoorway() returns false for rooms that arent doorways
		assertFalse(board.getCellAt(13, 17).isDoorway());
	}
	
	@Test
	public void testNumDoors() {
		//check every cell and if its a door, increment the number of doors
		int numDoors = 0;
		for(int x = 0; x < NUM_COLUMNS; x++) {
			for(int y = 0; y < NUM_ROWS; y++) {
				if(board.getCellAt(y, x).isDoorway()) {
					numDoors++;
				}
			}
		}
		//if the number of doors counted doesnt equal the actual number I counted, the test fails
		assertEquals(numDoors, 28);
	}
	
	public void testInitials() {
		//test a few random cells to make sure their initials match up with whats expected
		assertEquals(board.getCellAt(7, 6).getInitial(), 'W');
		assertEquals(board.getCellAt(21, 9).getInitial(), 'L');
		assertEquals(board.getCellAt(14, 19).getInitial(), 'B');
	}
}
