package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;

import clueGame.Board;
import clueGame.Card;
import clueGame.Clue;
import clueGame.Computer;
import clueGame.Player;
import clueGame.Solution;
import clueGame.Suggestion;

public class gameActionTests {
	
	Board board = Board.getInstance();
	
	@Before
	public void setUp() {
		Board.getInstance().setConfigFiles("gameboard.csv", "Rooms.txt");
		Board.getInstance().initialize();
		Player.setPlayerFile("Players.txt");
		Player.loadPlayerConfig();
		Card.createDecks();
		Solution.initializeSolution();
		Card.loadPlayerDecks();
	}
	
	@Test
	public void compPlayerLoc() { //pick location tile for computer players
		//test when no rooms in area
		Computer computer = new Computer("TEST NAME", 5, 5, null);
		assertTrue(computer.getTargets(2).contains(board.getCellAt(5, 7)));
		assertTrue(computer.getTargets(2).contains(board.getCellAt(5, 3)));
	
		//test with room
		computer = new Computer("jerry", 7, 9, null);
		assertTrue(computer.getTargets(2).contains(board.getCellAt(5, 9)));
		assertEquals(computer.getTargets(2).size(), 1);
		
		//tests if the computer chooses specifically the spot in the door
		assertEquals(computer.selectTarget(2), board.getCellAt(5, 9));
	}
	
	//make sure accusation checking goes smoothly
	@Test
	public void checkAccusation() {
		
		//check a correct accusation
		Solution correctSoln = new Solution(
				Solution.getSolution().getPerson(),
				Solution.getSolution().getRoom(),
				Solution.getSolution().getWeapon());
		assertTrue(correctSoln.checkSolution());
		
		//check accusation with wrong person
		int wrongPersonIndex = this.getDifferentIndex(Card.getPersonDeck(), Solution.getSolution().getPerson());
		Solution wrongPerson = new Solution(
				Card.getPersonDeck().get(wrongPersonIndex),
				Solution.getSolution().getRoom(),
				Solution.getSolution().getWeapon());
		assertFalse(wrongPerson.checkSolution());
		
		//check accusation with wrong room
		int wrongRoomIndex = this.getDifferentIndex(Card.getRoomDeck(), Solution.getSolution().getRoom());
		Solution wrongRoom = new Solution(
				Solution.getSolution().getPerson(),
				Card.getRoomDeck().get(wrongRoomIndex),
				Solution.getSolution().getWeapon());
		assertFalse(wrongRoom.checkSolution());
		
		//check accusation with wrong weapon
		int wrongWeaponIndex = this.getDifferentIndex(Card.getWeaponDeck(), Solution.getSolution().getWeapon());
		Solution wrongWeapon = new Solution(
				Solution.getSolution().getPerson(),
				Solution.getSolution().getRoom(),
				Card.getWeaponDeck().get(wrongWeaponIndex));
		assertFalse(wrongWeapon.checkSolution());
	}
	
	//helper function that, given a card deck and a target, will return any index other than the target card in that deck
	public int getDifferentIndex(ArrayList<Card> deck, Card target) {
		int index;
		for(index = 0; index < deck.size(); index++) {
			if(deck.get(index).equals(target)) {
				break;
			}
		}
		int wrongIndex = 0;
		while(wrongIndex == index) {
			wrongIndex = new Random(System.currentTimeMillis()).nextInt(deck.size());
		}
		return wrongIndex;
	}
	
	@Test
	public void disproveSuggestion() {
		//check a solution, after the player sees the solution, make sure only one card has been seen
		Suggestion s = new Suggestion(Card.getPersonDeck().get(0), Card.getRoomDeck().get(0), Card.getWeaponDeck().get(0));
		assertTrue(Player.getPlayers().get(1).getSeenCards().size() == 0);
		Player.getPlayers().get(1).seeDisprovedCard(s);
		assertTrue(Player.getPlayers().get(1).getSeenCards().size() == 1);
		
		setUp();
		
		//check a player guessing the solution
		//no cards should be added to the seen cards list
		s = new Suggestion(Solution.getSolution().getPerson(), Solution.getSolution().getRoom(), Solution.getSolution().getWeapon());
		assertTrue(Player.getPlayers().get(1).getSeenCards().size() == 0);
		Player.getPlayers().get(1).seeDisprovedCard(s);
		assertTrue(Player.getPlayers().get(1).getSeenCards().size() == 0);
	}
	@Test
	public void handleSuggestion() {
//		Card person1 = new Card(Card.getPerson(0));
		//make sure correct solution returns null
		Suggestion soln = new Suggestion(Solution.getSolution().getPerson(), Solution.getSolution().getRoom(), Solution.getSolution().getWeapon());
		assertEquals(Board.getInstance().handleSuggestion(soln, Player.getPlayers().get(1).getName()), null);
		
		//make sure a suggestion where the player making it has all the cards returns null
		Player comp1 = Player.getPlayers().get(1);
		soln = new Suggestion(comp1.getDeck().get(0), comp1.getDeck().get(1), comp1.getDeck().get(2));
		assertEquals(Board.getInstance().handleSuggestion(soln, Player.getPlayers().get(1).getName()), null);
		
		//suggestion only human can disprove returns card
		Player human = Player.getPlayers().get(0);
		Player comp5 = Player.getPlayers().get(5);
		comp5.setRow(16);
		comp5.setColumn(19);
		Suggestion s = Player.createRandomSuggestion(comp5);
		ArrayList<Card> newDeck = new ArrayList<Card>();
		newDeck.add(s.getPerson());
		newDeck.add(s.getRoom());
		newDeck.add(s.getWeapon());
		human.setDeck(newDeck);
		Card card = Board.getInstance().handleSuggestion(s, comp5.getName());
		assertTrue(card != null);
		
		//make sure human suggesting own cards returns null
		newDeck.clear();
		newDeck.add(Card.getPersonDeck().get(0));
		newDeck.add(Card.getRoomDeck().get(0));
		newDeck.add(Card.getWeaponDeck().get(0));
		human.setDeck(newDeck);
		soln = new Suggestion(newDeck.get(0), newDeck.get(1), newDeck.get(2));
		assertEquals(Board.getInstance().handleSuggestion(soln, human.getName()), null);
		
		//if multiple people can answer, only next person answers
		Player comp3 = Player.getPlayers().get(3);
		Player comp4 = Player.getPlayers().get(4);
		comp5 = Player.getPlayers().get(5);
		human = Player.getPlayers().get(0);
		
		//create two decks
		ArrayList<Card> deck1 = new ArrayList<Card>();
		deck1.add(Card.getPersonDeck().get(0));
		deck1.add(Card.getRoomDeck().get(0));
		deck1.add(Card.getWeaponDeck().get(0));
		
		ArrayList<Card> deck2 = new ArrayList<Card>();
		deck2.add(Card.getPersonDeck().get(1));
		deck2.add(Card.getRoomDeck().get(1));
		deck2.add(Card.getWeaponDeck().get(1));
		
		//set up p4 and p5 to have decks that both contain guesses in s
		//where s is a solution guessed by p3 so we can make sure
		//the card returned is from the soonest player in the turns
		comp4.setDeck(deck1);
		comp5.setDeck(deck2);
		s = new Suggestion(deck1.get(0), deck2.get(1), deck2.get(2));
		Card c = board.handleSuggestion(s, comp3.getName());
		assertEquals(c, deck1.get(0));
		
		//do the same shit as the previous test but with a human as the second player
		//which means nothing changes, but just in case
		human.setDeck(deck1);
		s = new Suggestion(deck1.get(0), deck1.get(1), deck2.get(2));
		c = board.handleSuggestion(s, comp4.getName());
		assertEquals(c, deck2.get(2));
	}
	@Test
	public void createCompSuggestion() {
		//make a suggestion in the current room
		Computer comp = new Computer("name", 20, 4, null);
		Suggestion s = Player.createRandomSuggestion(comp);
		assertEquals(s.getRoom().getName(), board.getLegend().get(board.getCellAt(comp.getRow(), comp.getColumn()).getInitial()));
		assertFalse(comp.hasSeenCard(s.getPerson()));
		assertFalse(comp.hasSeenCard(s.getRoom()));
		assertFalse(comp.hasSeenCard(s.getWeapon()));
		comp.witnessSuggestion(s);
		
		//test a random room
//		comp = new Computer("name", 20, 4, null);
		s = Player.createRandomSuggestion(comp);
		assertEquals(s.getRoom().getName(), board.getLegend().get(board.getCellAt(comp.getRow(), comp.getColumn()).getInitial()));
		assertFalse(comp.hasSeenCard(s.getPerson()));
		//this normally isnt what you want because its another suggestion in the same room;
		//but we know what we're looking for so we let it slide
		assertTrue(comp.hasSeenCard(s.getRoom()));
		assertFalse(comp.hasSeenCard(s.getWeapon()));
		comp.witnessSuggestion(s);
		
		//test a random room
//		comp = new Computer("name", 20, 4, null);
		s = Player.createRandomSuggestion(comp);
		assertEquals(s.getRoom().getName(), board.getLegend().get(board.getCellAt(comp.getRow(), comp.getColumn()).getInitial()));
		assertFalse(comp.hasSeenCard(s.getPerson()));
		//see comment in line 122
		assertTrue(comp.hasSeenCard(s.getRoom()));
		assertFalse(comp.hasSeenCard(s.getWeapon()));
		
		
		//show the computer every weapon so when it makes the next suggestion it only has one option
		comp = new Computer("name", 20, 4, null);
		comp.witnessSuggestion(new Suggestion(Card.getPersonDeck().get(0), Card.getRoomDeck().get(0), Card.getWeaponDeck().get(0)));
		comp.witnessSuggestion(new Suggestion(Card.getPersonDeck().get(0), Card.getRoomDeck().get(0), Card.getWeaponDeck().get(1)));
		comp.witnessSuggestion(new Suggestion(Card.getPersonDeck().get(0), Card.getRoomDeck().get(0), Card.getWeaponDeck().get(2)));
		comp.witnessSuggestion(new Suggestion(Card.getPersonDeck().get(0), Card.getRoomDeck().get(0), Card.getWeaponDeck().get(3)));
		comp.witnessSuggestion(new Suggestion(Card.getPersonDeck().get(0), Card.getRoomDeck().get(0), Card.getWeaponDeck().get(4)));
		s = Player.createRandomSuggestion(comp);
		assertEquals(s.getWeapon(), Card.getWeaponDeck().get(5));
	}
}
