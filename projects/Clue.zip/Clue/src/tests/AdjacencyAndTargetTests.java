//David Fresco and Grant Marsh

package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import clueGame.Board;
import clueGame.BoardCell;

public class AdjacencyAndTargetTests {
	
	private static Board board;
	
	@Before
	public void setUp() {
		board = Board.getInstance();
		board.setConfigFiles("gameboard.csv", "Rooms.txt");
		board.initialize();
	}
	
	/*
	 * test walkways surrounded by more walkway
	 * walkways next to rooms
	 * walkways on edges of the board
	 * green
	 */
	@Test 
	public void walkwayNoDoorAdj() {
		//left edge of board
		Set<BoardCell> adj = board.getAdjList(11, 0);
		assertEquals(adj.size(), 2);
		assertTrue(adj.contains(board.getCellAt(11, 1)));
		assertTrue(adj.contains(board.getCellAt(12, 0)));
		
		//top edge
		adj = board.getAdjList(0, 7);
		assertEquals(adj.size(), 2);
		assertTrue(adj.contains(board.getCellAt(1, 7)));
		assertTrue(adj.contains(board.getCellAt(0, 6)));
		
		//right edge
		adj = board.getAdjList(13, 22);
		assertEquals(adj.size(), 2);
		assertTrue(adj.contains(board.getCellAt(12, 22)));
		assertTrue(adj.contains(board.getCellAt(13, 21)));
		
		//bottom edge
		adj = board.getAdjList(20, 5);
		assertEquals(adj.size(), 1);
		assertTrue(adj.contains(board.getCellAt(19, 5)));
		
		//middle of walkway
		adj = board.getAdjList(6, 14);
		assertEquals(adj.size(), 4);
		assertTrue(adj.contains(board.getCellAt(5, 14)));
		assertTrue(adj.contains(board.getCellAt(7, 14)));
		assertTrue(adj.contains(board.getCellAt(6, 15)));
		assertTrue(adj.contains(board.getCellAt(6, 13)));
	}
	
	/*
	 * test adjacencies to cells inside rooms
	 * tests cells in the open, at board corners and edges, next to walkways
	 * orange
	 */
	@Test
	public void insideRoomAdj() {
		//top left corner
		Set<BoardCell> adj = board.getAdjList(0, 0);
		assertEquals(adj.size(), 0);
		
		//top edge
		adj = board.getAdjList(0, 18);
		assertEquals(adj.size(), 0);
		
		//corner of room bordering walkway
		adj = board.getAdjList(18, 11);
		assertEquals(adj.size(), 0);
		
		//middle of room
		adj = board.getAdjList(15, 1);
		assertEquals(adj.size(), 0);
	}
	
	/*
	 * tests cells adjacent to doors
	 * test from both inside and outside rooms
	 * blue
	 */
	@Test
	public void nextToDoorAdj() {
		Set<BoardCell> adj;
		//in room
		adj = board.getAdjList(3, 4);
		assertEquals(adj.size(), 1);
		assertTrue(adj.contains(board.getCellAt(4, 4)));
		
		adj = board.getAdjList(14, 19);
		assertEquals(adj.size(), 1);
		assertTrue(adj.contains(board.getCellAt(13, 19)));
		
		//in walkway
		adj = board.getAdjList(4, 20);
		assertEquals(adj.size(), 4);
		assertTrue(adj.contains(board.getCellAt(5, 20)));
		assertTrue(adj.contains(board.getCellAt(4, 19)));
		assertTrue(adj.contains(board.getCellAt(4, 21)));
		
		adj = board.getAdjList(15, 5);
		assertEquals(adj.size(), 4);
		assertTrue(adj.contains(board.getCellAt(15, 6)));
		assertTrue(adj.contains(board.getCellAt(14, 5)));
		assertTrue(adj.contains(board.getCellAt(16, 5)));
	}
	
	/*
	 * test target list in walkways
	 * red
	 */
	@Test
	public void walkwayTarget() {
		Set<BoardCell> targets;
		
		board.calcTargets(8, 6, 2); //path length 2
		targets = board.getTargets();
		
		assertTrue(targets.contains(board.getCellAt(6, 6)));
		assertTrue(targets.contains(board.getCellAt(7, 7)));
		assertTrue(targets.contains(board.getCellAt(7, 5)));
		assertTrue(targets.contains(board.getCellAt(8, 4)));
		assertTrue(targets.contains(board.getCellAt(9, 5)));
		assertTrue(targets.contains(board.getCellAt(10, 6)));
		
		board.calcTargets(12, 18, 3); //path length 3
		targets = board.getTargets();
		
		assertTrue(targets.contains(board.getCellAt(13, 16)));
		assertTrue(targets.contains(board.getCellAt(12, 21)));
		assertTrue(targets.contains(board.getCellAt(13, 20)));
		assertTrue(targets.contains(board.getCellAt(12, 15)));
		assertTrue(targets.contains(board.getCellAt(11, 16)));
		assertTrue(targets.contains(board.getCellAt(10, 17)));
		
		board.calcTargets(3, 15, 4); //path length 4
		targets = board.getTargets();
		
		assertTrue(targets.contains(board.getCellAt(4, 18)));
		assertTrue(targets.contains(board.getCellAt(5, 17)));
		assertTrue(targets.contains(board.getCellAt(6, 16)));
		assertTrue(targets.contains(board.getCellAt(7, 15)));
		assertTrue(targets.contains(board.getCellAt(0, 14)));
		assertTrue(targets.contains(board.getCellAt(4, 12)));
	}
	
	/*
	 * test target list when entering rooms
	 * purple
	 */
	@Test
	public void enteringRoomTargets() {
		Set<BoardCell> enterTargets;
		
		board.calcTargets(8, 16, 2); //path length 2
		enterTargets = board.getTargets();
		
		assertTrue(enterTargets.contains(board.getCellAt(6, 16)));
		assertTrue(enterTargets.contains(board.getCellAt(7, 17)));
		//door target
		assertTrue(enterTargets.contains(board.getCellAt(8, 18)));
		assertTrue(enterTargets.contains(board.getCellAt(10, 16)));
		assertTrue(enterTargets.contains(board.getCellAt(7, 15)));
		assertTrue(enterTargets.contains(board.getCellAt(9, 15)));
		
		board.calcTargets(2, 12, 2); //path length 2
		enterTargets = board.getTargets();
		
		assertTrue(enterTargets.contains(board.getCellAt(0, 12)));
		assertTrue(enterTargets.contains(board.getCellAt(2, 14)));
		//door target
		assertTrue(enterTargets.contains(board.getCellAt(2, 11)));
		assertTrue(enterTargets.contains(board.getCellAt(4, 12)));
		
	}
	
	/*
	 * test target list when leaving rooms
	 * dark blue
	 */
	@Test
	public void leavingRoomTargets() {
		Set<BoardCell> leaveTargets;
		
		board.calcTargets(2, 5, 2); //path length 2
		leaveTargets = board.getTargets();
		
		assertTrue(leaveTargets.contains(board.getCellAt(1, 6)));
		assertTrue(leaveTargets.contains(board.getCellAt(2, 7)));
		assertTrue(leaveTargets.contains(board.getCellAt(3, 6)));
		
		board.calcTargets(15, 9, 3); //path length 3
		leaveTargets = board.getTargets();
		
		assertTrue(leaveTargets.contains(board.getCellAt(13, 8)));
		assertTrue(leaveTargets.contains(board.getCellAt(13, 10)));
		assertTrue(leaveTargets.contains(board.getCellAt(14, 11)));
		assertTrue(leaveTargets.contains(board.getCellAt(15, 10)));
		
	}
}