//David Fresco and Grant Marsh

package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.awt.Color;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import clueGame.Board;
import clueGame.Card;
import clueGame.Card.CardType;
import clueGame.Computer;
import clueGame.Human;
import clueGame.Player;
import clueGame.Solution;

public class gameSetupTests {

	@Before
	public void setUp() {
		Board.getInstance().setConfigFiles("gameboard.csv", "Rooms.txt");
		Board.getInstance().initialize();
		Player.setPlayerFile("Players.txt");
		Player.loadPlayerConfig();
		Card.createDecks();
		Solution.initializeSolution();
		Card.loadPlayerDecks();
	}
	
	@Test
	public void loadPeopleTest() {
		//test the first player
		Player player = Player.getPlayers().get(0);
		assertEquals(player.getName(), "Scarlet");
		assertEquals(player.getColor(), Color.RED);
		assertEquals(player.getRow(), 20);
		assertEquals(player.getColumn(), 9);
		assertTrue(player instanceof Human);
		
		//test a player in the middle of the list
		player = Player.getPlayers().get(2);
		assertEquals(player.getName(), "Peacock");
		assertEquals(player.getColor(), Color.BLUE);
		assertEquals(player.getRow(), 4);
		assertEquals(player.getColumn(), 0);
		assertTrue(player instanceof Computer);
		
		//test a player at the end of the list
		player = Player.getPlayers().get(5);
		assertEquals(player.getName(), "Green");
		assertEquals(player.getColor(), Color.GREEN);
		assertEquals(player.getRow(), 13);
		assertEquals(player.getColumn(), 22);
		assertTrue(player instanceof Computer);
	}
	
	@Test
	public void loadDeckTest() {
		//make sure we have the right number of cards
		assertEquals(Card.getPersonDeck().size(), 6);
		
		//test first person card
		Card personCard = Card.getPersonDeck().get(0);
		assertEquals(personCard.getName(), "Scarlet");
		assertEquals(personCard.getType(), CardType.PERSON);
		
		//test middle person card
		personCard = Card.getPersonDeck().get(3);
		assertEquals(personCard.getName(), "Mustard");
		assertEquals(personCard.getType(), CardType.PERSON);
		
		//test last person card
		personCard = Card.getPersonDeck().get(5);
		assertEquals(personCard.getName(), "Green");
		assertEquals(personCard.getType(), CardType.PERSON);
		
		//test num room cards
		assertEquals(Card.getWeaponDeck().size(), 6);
		
		//test first weapon card
		Card weaponCard = Card.getWeaponDeck().get(0);
		assertEquals(weaponCard.getName(), "Gun");
		assertEquals(weaponCard.getType(), CardType.WEAPON);
		
		//test middle weapon card
		weaponCard = Card.getWeaponDeck().get(2);
		assertEquals(weaponCard.getName(), "Hammer");
		assertEquals(weaponCard.getType(), CardType.WEAPON);
		
		//test last weapon card
		weaponCard = Card.getWeaponDeck().get(5);
		assertEquals(weaponCard.getName(), "Hand Grenade");
		assertEquals(weaponCard.getType(), CardType.WEAPON);
		
		//test num room cards
		assertEquals(Card.getRoomDeck().size(), 9);
		
		//test first room card
		Card roomCard = Card.getRoomDeck().get(0);
		assertEquals(roomCard.getName(), "Treasurer's Room");
		assertEquals(roomCard.getType(), CardType.ROOM);
		
		//test middle room card
		roomCard = Card.getRoomDeck().get(5);
		assertEquals(roomCard.getName(), "Library");
		assertEquals(roomCard.getType(), CardType.ROOM);
		
		//test last room card
		roomCard = Card.getRoomDeck().get(8);
		assertEquals(roomCard.getName(), "Basement");
		assertEquals(roomCard.getType(), CardType.ROOM);
	}
	
	@Test
	public void dealCardsTest() {
		Set<Card> cardsDealt = new HashSet<Card>();
		int totalCards = 0;
		for(Player p : Player.getPlayers()) {
			totalCards += p.getDeck().size();
			for(Card c : p.getDeck()) {
				if(cardsDealt.contains(c))
					fail();
				cardsDealt.add(c);
			}
			assertEquals(p.getDeck().size(), 3);
		}
		assertEquals(totalCards, 18);
	}
}
