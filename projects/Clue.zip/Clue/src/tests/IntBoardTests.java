package tests;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import experiment.BoardCell;
import experiment.IntBoard;

public class IntBoardTests {
	
	private IntBoard board;
	
	@Before
	public void setup() {
		board = new IntBoard();
	}
	
	@Test
	public void testTopLeftAdjacency() {
		Set<BoardCell> adjacents = board.getAdjList(board.getCell(0, 0));
		if(adjacents.size() != 2) {
			fail("adj list size for (0, 0) is not 2");
		}
		if(!adjacents.contains(board.getCell(1, 0)) || !adjacents.contains(board.getCell(0, 1))) {
			fail("adj list does not contain (1, 0) or (0, 1)");
		}
	}
	
	@Test
	public void testBottomRightAdjacency() {
		Set<BoardCell> adjacents = board.getAdjList(board.getCell(IntBoard.BOARD_SIZE_X-1, IntBoard.BOARD_SIZE_Y-1));
		if(adjacents.size() != 2) {
			fail("adj list size for (23, 21) is not 2");
		}
		if(!adjacents.contains(board.getCell(IntBoard.BOARD_SIZE_X-1, IntBoard.BOARD_SIZE_Y-2)) 
				|| !adjacents.contains(board.getCell(IntBoard.BOARD_SIZE_X-1, IntBoard.BOARD_SIZE_Y-2))) {
			fail("adj list does not contain (23, 20) or (22, 21)");
		}
	}
	
	@Test
	public void testRightEdge() {
		Set<BoardCell> adjacents = board.getAdjList(board.getCell(IntBoard.BOARD_SIZE_X-1, 8));
		if(adjacents.size() != 3) {
			fail("adj list size for (23, 8) is not 3");
		}
		if(!adjacents.contains(board.getCell(IntBoard.BOARD_SIZE_X-1, 7)) 
				|| !adjacents.contains(board.getCell(IntBoard.BOARD_SIZE_X-1, 9))
				|| !adjacents.contains(board.getCell(IntBoard.BOARD_SIZE_X-2, 8))) {
			fail("adj list does not contain (23, 7) or (23, 9) or (22, 8)");
		}
	}
	
	@Test
	public void testBottomEdge() {
		Set<BoardCell> adjacents = board.getAdjList(board.getCell(12, IntBoard.BOARD_SIZE_Y-1));
		if(adjacents.size() != 3) {
			fail("adj list size for (12, 21) is not 3");
		}
		if(!adjacents.contains(board.getCell(11, IntBoard.BOARD_SIZE_Y-1)) 
				|| !adjacents.contains(board.getCell(13, IntBoard.BOARD_SIZE_Y-1))
				|| !adjacents.contains(board.getCell(12, IntBoard.BOARD_SIZE_Y-2))) {
			fail("adj list does not contain (11, 21) or (13, 21) or (12, 20)");
		}
	}
	
	@Test
	//tests (1, 1)
	public void testAlmostTopLeftAdjacency() {
		Set<BoardCell> adjacents = board.getAdjList(board.getCell(1, 1));
		if(adjacents.size() != 4) {
			fail("adj list size for (1, 1) is not 4");
		}
		if(!adjacents.contains(board.getCell(1, 0)) 
				|| !adjacents.contains(board.getCell(0, 1))
				|| !adjacents.contains(board.getCell(1, 2))
				|| !adjacents.contains(board.getCell(2, 1))) {
			fail("adj list does not contain (1, 0) or (0, 1) or (1, 2) or (2, 1)");
		}
	}
	
	@Test
	public void testAlmostBottomRightAdjacency() {
		Set<BoardCell> adjacents = board.getAdjList(board.getCell(IntBoard.BOARD_SIZE_X-2, IntBoard.BOARD_SIZE_Y-2));
		if(adjacents.size() != 4) {
			fail("adj list size for (1, 1) is not 4");
		}
		if(!adjacents.contains(board.getCell(IntBoard.BOARD_SIZE_X-1, IntBoard.BOARD_SIZE_Y-2)) 
				|| !adjacents.contains(board.getCell(IntBoard.BOARD_SIZE_X-2, IntBoard.BOARD_SIZE_Y-1))
				|| !adjacents.contains(board.getCell(IntBoard.BOARD_SIZE_X-2, IntBoard.BOARD_SIZE_Y-3))
				|| !adjacents.contains(board.getCell(IntBoard.BOARD_SIZE_X-3, IntBoard.BOARD_SIZE_Y-2))) {
			fail("adj list does not contain cells adjacent to (22, 20)");
		}
	}
	
	@Test
	public void testTargets2Steps() {
		board.calcTargets(board.getCell(6, 7), 2);
		assertTrue(board.getTargets().contains(board.getCell(4, 7)));
		assertTrue(board.getTargets().contains(board.getCell(8, 7)));
		assertTrue(board.getTargets().contains(board.getCell(6, 9)));
		assertTrue(board.getTargets().contains(board.getCell(6, 5)));
		assertTrue(board.getTargets().contains(board.getCell(5, 6)));
		assertTrue(board.getTargets().contains(board.getCell(7, 6)));
		assertTrue(board.getTargets().contains(board.getCell(5, 8)));
		assertTrue(board.getTargets().contains(board.getCell(7, 8)));
	}
	
	@Test
	public void testTargets1Step() {
		board.calcTargets(board.getCell(20, 17), 1);
		assertTrue(board.getTargets().contains(board.getCell(19, 17)));
		assertTrue(board.getTargets().contains(board.getCell(21, 17)));
		assertTrue(board.getTargets().contains(board.getCell(20, 16)));
		assertTrue(board.getTargets().contains(board.getCell(20, 18)));
	}
}
