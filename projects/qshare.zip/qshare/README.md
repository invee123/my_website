# qshare
its an app that does some things but not all things
