package com.fourdudes.qshare.WelcomePage

import androidx.fragment.app.Fragment

class WelcomeFragment: Fragment() {

}